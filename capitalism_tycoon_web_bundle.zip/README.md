# Capitalism Tycoon (Idle Game)

Jeu idle/tycoon prêt à être déployé en **GitHub Pages** ou **Netlify**.

## Lancement local
Ouvre `index.html` dans ton navigateur.

## Déploiement — GitHub Pages (recommandé, simple)
1. Crée un repo GitHub (public) nommé par ex. `capitalism-tycoon`.
2. Envoie ces fichiers : `index.html`, `style.css`, `main.js`, dossier `assets/`.
3. Dans **Settings → Pages**, choisis **Branch: `main`** et **/ (root)**, puis **Save**.
4. Attends ~1 minute, ton jeu sera disponible à une URL du type :  
   `https://<ton-user>.github.io/capitalism-tycoon/`

### Commandes Git en ligne de commande
```bash
git init
git add .
git commit -m "Initial commit — Capitalism Tycoon"
git branch -M main
git remote add origin https://github.com/<ton-user>/capitalism-tycoon.git
git push -u origin main
```
Ensuite active **Settings → Pages** comme ci‑dessus.

## Déploiement — Netlify (CDN très rapide)
1. Va sur https://app.netlify.com/ et clique **New site from Git** (connecte GitHub)  
   *ou* utilise **Deploy a site → Drag & drop** et glisse le dossier du jeu.
2. Build command: _vide_, Publish directory: `/` (root).  
3. Netlify donne une URL instantanément (modifiable).

---

Graphismes : reprend la charte générée (image `assets/hero.png`).  
Sauvegarde automatique via `localStorage`. Export/Import inclus.
